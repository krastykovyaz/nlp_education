Sixth assignment:
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/ml-course/blob/23s_advanced/homeworks_advanced/assignment01_text_classification/assignment01.ipynb)

