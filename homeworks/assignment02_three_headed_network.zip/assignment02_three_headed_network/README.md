Assignment on more complex network:
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/ml-course/blob/23s_advanced/homeworks_advanced/assignment02_three_headed_network/assignment02_three_headed_network.ipynb)
